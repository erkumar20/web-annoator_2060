**WEB ANNOTATOR PROJECT**

**Setup:**

1. first clone this repo
2. and then run npm intall
3. run npx webpack-cli watch
4. wait for the the changes in dist folder to complete
5. now upload this dist folder on "load unpack" in chrome extension. (Enable developer mode for this)
6. Pin the extension.

**KeyBoard shortcuts:**

1. Ctrl + RShift + H -> for adding new highlight.
2. Ctrl + RShift + F -> for searching specific highlight.
